def escalation_decision(intent_confidence, evidence_similarity, risk=False, conf_threshold=.62, sim_threshold=.18):
    reasons=[]
    if intent_confidence < conf_threshold: reasons.append('low intent confidence')
    if evidence_similarity < sim_threshold: reasons.append('weak historical evidence')
    if risk: reasons.append('potentially sensitive/high-risk request')
    return {'decision':'escalate' if reasons else 'auto_handle','reason':'; '.join(reasons) if reasons else 'high-confidence intent with sufficient historical evidence'}
