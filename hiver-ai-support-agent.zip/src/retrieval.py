import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

class HistoricalRetriever:
    def __init__(self, df, max_features=30000):
        self.df=df.reset_index(drop=True).copy()
        self.vec=TfidfVectorizer(lowercase=True,ngram_range=(1,2),min_df=1,max_features=max_features,sublinear_tf=True)
        self.X=self.vec.fit_transform(self.df.customer_message.fillna(''))
    def retrieve(self, query, k=3):
        q=self.vec.transform([query]); scores=cosine_similarity(q,self.X).ravel(); ids=scores.argsort()[::-1][:k]
        return self.df.iloc[ids].assign(similarity=scores[ids])
