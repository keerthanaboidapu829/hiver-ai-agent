from pathlib import Path
import pandas as pd, joblib
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, f1_score, classification_report

INPUT='evaluation/golden_set.csv'; MODEL='src/intent_model.joblib'; VEC='src/tfidf_vectorizer.joblib'

def train():
    df=pd.read_csv(INPUT).dropna(subset=['final_intent'])
    df=df[df['final_intent'].astype(str).str.strip()!='']
    X=df.customer_message.fillna(''); y=df.final_intent
    tr,te=train_test_split(range(len(df)),test_size=.2,random_state=42,stratify=y)
    vec=TfidfVectorizer(lowercase=True,stop_words='english',ngram_range=(1,2),min_df=2,max_features=20000)
    Xt=vec.fit_transform(X.iloc[tr]); Xv=vec.transform(X.iloc[te])
    model=LogisticRegression(max_iter=1000,class_weight='balanced').fit(Xt,y.iloc[tr])
    p=model.predict(Xv); acc=accuracy_score(y.iloc[te],p); f1=f1_score(y.iloc[te],p,average='macro')
    print(f'Accuracy: {acc:.4f}\nMacro F1: {f1:.4f}\n'); print(classification_report(y.iloc[te],p,zero_division=0))
    joblib.dump(model,MODEL); joblib.dump(vec,VEC)
    return acc,f1
if __name__=='__main__': train()
