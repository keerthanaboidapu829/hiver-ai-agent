from pathlib import Path
import html, re
import pandas as pd

DATA_PATH = Path('data/twcs.csv')
OUTPUT_PATH = Path('data/applesupport_conversations.csv')
COLS = ['tweet_id','author_id','inbound','created_at','text','response_tweet_id','in_response_to_tweet_id']

def clean_text(x):
    x = html.unescape(str(x or ''))
    x = re.sub(r'https?://\S+', ' ', x)
    x = re.sub(r'\s+', ' ', x).strip()
    return x

def build_pairs(path=DATA_PATH, out=OUTPUT_PATH):
    support=[]; inbound=[]
    for chunk in pd.read_csv(path, encoding='latin-1', usecols=COLS, chunksize=200_000):
        chunk['tweet_id']=chunk['tweet_id'].astype(str)
        chunk['in_response_to_tweet_id']=chunk['in_response_to_tweet_id'].astype('Int64').astype(str)
        a=chunk[chunk.author_id.eq('AppleSupport') & chunk.in_response_to_tweet_id.notna()].copy()
        a=a[['tweet_id','created_at','text','in_response_to_tweet_id']]
        support.append(a)
        b=chunk[chunk.inbound.eq(True) | chunk.inbound.eq(1)].copy()
        b=b[['tweet_id','author_id','created_at','text']]
        inbound.append(b)
    s=pd.concat(support, ignore_index=True).drop_duplicates('tweet_id')
    c=pd.concat(inbound, ignore_index=True).drop_duplicates('tweet_id')
    c=c.rename(columns={'tweet_id':'customer_tweet_id','created_at':'customer_created_at','text':'customer_message'})
    s=s.rename(columns={'tweet_id':'support_tweet_id','created_at':'support_created_at','text':'support_reply','in_response_to_tweet_id':'customer_tweet_id'})
    outdf=s.merge(c,on='customer_tweet_id',how='inner')
    outdf['customer_message']=outdf.customer_message.map(clean_text)
    outdf['support_reply']=outdf.support_reply.map(clean_text)
    outdf=outdf[['customer_tweet_id','support_tweet_id','customer_created_at','support_created_at','customer_message','support_reply']]
    out.parent.mkdir(parents=True,exist_ok=True); outdf.to_csv(out,index=False)
    print(f'Pairs: {len(outdf):,}')

if __name__=='__main__': build_pairs()
