from pathlib import Path
import pandas as pd, joblib
from retrieval import HistoricalRetriever
from reply_generator import draft_reply
from escalation import escalation_decision

INTENT_MODEL='src/intent_model.joblib'; VEC='src/tfidf_vectorizer.joblib'; DATA='data/applesupport_conversations.csv'

def load():
    return joblib.load(INTENT_MODEL), joblib.load(VEC), HistoricalRetriever(pd.read_csv(DATA))

def run(message):
    model,vec,retriever=load(); x=vec.transform([message]); probs=model.predict_proba(x)[0]; i=probs.argmax(); intent=model.classes_[i]; conf=float(probs[i])
    ev=retriever.retrieve(message,3); sim=float(ev.iloc[0].similarity) if len(ev) else 0
    reply=draft_reply(message,ev); decision=escalation_decision(conf,sim)
    return {'intent':intent,'intent_confidence':conf,'reply':reply,'decision':decision['decision'],'reason':decision['reason'],'evidence':ev[['customer_message','support_reply','similarity']].to_dict('records')}
