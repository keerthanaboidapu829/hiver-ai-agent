def draft_reply(customer_message, evidence):
    if evidence is None or len(evidence)==0:
        return ('Thanks for reaching out. We need a little more information to help with this issue. '
                'Please share the relevant device/app details and any error message you see.')
    best=evidence.iloc[0]
    historical=str(best.get('support_reply','')).strip()
    if not historical:
        return 'Thanks for reaching out. Please share a few more details about the issue so we can help.'
    return historical
