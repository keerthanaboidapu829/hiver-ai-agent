import pandas as pd
from sklearn.metrics import accuracy_score, f1_score

def evaluate(path='evaluation/golden_set.csv'):
    df=pd.read_csv(path)
    print('Golden examples:',len(df))
    print('Label distribution:\n',df.final_intent.value_counts())
    print('\nNote: populate predicted_intent after running the pipeline to compute model metrics.')
    if 'predicted_intent' in df:
        print('Accuracy:',accuracy_score(df.final_intent,df.predicted_intent))
        print('Macro F1:',f1_score(df.final_intent,df.predicted_intent,average='macro'))
if __name__=='__main__': evaluate()
