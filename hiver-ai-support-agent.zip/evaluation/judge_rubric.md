# Reply Judge Rubric

Score each drafted reply 1–5 on:
- Relevance to the customer issue
- Groundedness in retrieved historical evidence
- Helpfulness/actionability
- Tone and professionalism
- Non-hallucination / unsupported claims

Also record `escalation_correct` as yes/no. Compare an LLM judge against a human subset (recommended: 50 examples) and report agreement.
