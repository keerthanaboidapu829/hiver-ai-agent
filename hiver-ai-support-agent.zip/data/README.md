# Data

The Hiver take-home uses the Kaggle **Customer Support on Twitter** dataset. Download the CSV and place it at `data/twcs.csv` (or change `DATA_PATH`).

The raw dataset is intentionally **not committed** because it is large. The processing code expects these columns:

- `tweet_id`
- `author_id`
- `inbound`
- `created_at`
- `text`
- `response_tweet_id`
- `in_response_to_tweet_id`

The selected brand is **AppleSupport**. `src/data_processing.py` extracts customer→AppleSupport response pairs and can also reconstruct lightweight conversation context from parent links.
