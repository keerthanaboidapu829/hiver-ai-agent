# Decision Log

1. **AppleSupport** selected because it has a large volume and recurring technical-support patterns.
2. **Seven intents** keep the taxonomy small enough to label consistently.
3. **Account and purchase issues are combined** because password, subscription, payment and refund conversations overlap in the source data.
4. **Keyword exploration is not treated as ground truth**; final labels must be human-reviewed.
5. **TF-IDF + logistic regression** is the simple learned baseline because it is fast and interpretable.
6. **Historical retrieval precedes generation** to reduce unsupported answers.
7. **Historical replies are preserved as evidence** rather than paraphrased without traceability.
8. **Escalation uses confidence + evidence thresholds** rather than intent alone.
9. **Raw Kaggle data is excluded from Git** because it is large and unnecessary for source control.
10. **Conversation-level splitting should be used for final evaluation** to avoid leakage between turns from the same thread.
11. **Golden labels are separated from suggested labels** to preserve evaluation integrity.
12. **LLM judging is secondary to human agreement** and should be calibrated on a human-labelled subset.
