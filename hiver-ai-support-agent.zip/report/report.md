# Hiver SDE Intern Take-Home — AppleSupport AI Support Agent

## 1. Framing
Build an AI support agent for AppleSupport that predicts a compact issue intent, retrieves historically similar support resolutions, drafts an evidence-grounded response, and decides whether to auto-handle or escalate.

## 2. What is built
- TF-IDF + logistic regression intent classifier.
- Historical TF-IDF retrieval over customer→support pairs.
- Evidence-backed draft response.
- Confidence/evidence based escalation decision.
- Evaluation harness and golden-set schema.

## 3. What is not built yet
- Production LLM integration and model-hosting layer.
- Full multi-turn thread reconstruction for every conversation.
- Final 150–250-example hand-labelled golden set (the repository includes a starter file; labels must be completed by the candidate).
- Calibrated LLM-as-judge agreement study.

## 4. Baselines
1. Trivial majority-class baseline.
2. TF-IDF + logistic regression simple learned baseline.

The final report should fill in measured results after the complete golden set is labelled and the harness is run.

## 5. Top failure modes / hypotheses
1. Short ambiguous tweets lack enough signal → add thread context.
2. Overlapping intents such as update vs battery → multi-label or hierarchical classification.
3. Historical replies may be stale → retrieve multiple examples and judge evidence quality.
4. Billing/security requests can be high-risk → route conservatively.
5. Similar wording can hide different root causes → include surrounding turns in retrieval.

## 6. What is misleading about my headline number?
A high intent score can be misleading if examples from the same conversation appear in both train and test, or if the golden set is too easy. The headline must therefore be conversation-separated and accompanied by class-wise metrics and human/LLM reply-quality evidence.

## 7. One more week
Reconstruct complete threads, add a stronger sentence-embedding retriever, integrate a constrained LLM generator, calibrate escalation thresholds, expand the human-labelled golden set, and run a blinded human evaluation.
