# AppleSupport AI Support Agent — Hiver SDE Intern Take-Home

A proof-first support agent built on the Customer Support on Twitter dataset.

## Pipeline
`customer message → intent → historical retrieval → grounded draft → auto-handle/escalate`

### Intent taxonomy
- `software_update`
- `device_hardware`
- `battery_charging`
- `app_service`
- `connectivity`
- `account_purchase`
- `general_support`

## Quick start
```bash
python -m venv .venv
# Windows: .venv\\Scripts\\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
```

Place the Kaggle CSV at `data/twcs.csv`, then:

```bash
python src/data_processing.py
python src/intent_classifier.py
python evaluation/evaluate.py
```

The raw dataset is intentionally not committed. Complete `evaluation/golden_set.csv` to 150–250 hand-labelled examples before reporting final metrics.

## Reproducibility note
For the final submission, use conversation-level train/test separation and report the majority baseline, TF-IDF baseline, classifier, retrieval quality, reply judge scores, and human-vs-LLM judge agreement. Do not present keyword-generated labels as hand-labelled ground truth.

## Structure
- `src/` — processing, classifier, retrieval, response and escalation pipeline
- `evaluation/` — golden set and evaluation harness
- `report/` — submission report
- `decision_log.md` — non-obvious implementation decisions
